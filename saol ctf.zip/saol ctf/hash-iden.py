import argparse
import sys
import random
import os
import time
import pyfiglet
import re
import base64
import codecs
from urllib.parse import unquote
import subprocess
import sys

def install_packages():
    required_packages = ["pyfiglet"]

    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            print(f"[!] '{package}' not found. Installing...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        else:
            print(f"[+] '{package}' is already installed.")

class HashIdentifier:
    HASH_PATTERNS = {
        r'^[a-fA-F0-9]{32}$': 'MD5, NTLM, MD4',
        r'^[a-fA-F0-9]{40}$': 'SHA-1, MySQL5',
        r'^[a-fA-F0-9]{64}$': 'SHA-256',
        r'^[a-fA-F0-9]{96}$': 'SHA-384',
        r'^[a-fA-F0-9]{128}$': 'SHA-512, Whirlpool',
        r'^[a-fA-F0-9]{16}$': 'MySQL',
        r'^\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}$': 'BCRYPT',
        r'^[a-fA-F0-9]{35}$': 'md5(md5($pass).$salt)',
        r'^[a-fA-F0-9]{54}$': 'MSSQL2015',
        r'^.{60}$': 'BCRYPT',
    }

    @staticmethod
    def detect_encoding(text):
        encodings = []

        # ROT13 Detection
        try:
            if text.isalpha():
                decoded = codecs.encode(text, 'rot_13')
                if codecs.encode(decoded, 'rot_13') == text:
                    encodings.append("ROT13")
        except Exception:
            pass

        # Base64 Detection
        try:
            if re.match(r'^[A-Za-z0-9+/=]{4,}$', text):
                decoded = base64.b64decode(text).decode('utf-8')
                if base64.b64encode(decoded.encode('utf-8')).decode('utf-8') == text:
                    encodings.append("Base64")
        except Exception:
            pass

        # Base32 Detection
        try:
            if re.match(r'^[a-zA-Z2-7=]{8,}$', text):
                decoded = base64.b32decode(text).decode('utf-8')
                if base64.b32encode(decoded.encode('utf-8')).decode('utf-8') == text:
                    encodings.append("Base32")
        except Exception:
            pass

        # Base16 Detection
        try:
            if re.match(r'^[A-F0-9]{2,}$', text):
                decoded = base64.b16decode(text).decode('utf-8')
                if base64.b16encode(decoded.encode('utf-8')).decode('utf-8') == text:
                    encodings.append("Base16")
        except Exception:
            pass

        # Hexadecimal Detection
        try:
            if re.match(r'^[a-fA-F0-9]+$', text):
                bytes_data = bytes.fromhex(text)
                if text == bytes_data.hex():
                    encodings.append("Hexadecimal")
        except Exception:
            pass

        # URL Encoding Detection
        try:
            decoded = unquote(text)
            if decoded != text:
                encodings.append("URL Encoding")
        except Exception:
            pass

        # JWT Detection
        try:
            if len(text.split('.')) == 3:
                header, payload, signature = text.split('.')
                base64.b64decode(header + '==')
                base64.b64decode(payload + '==')
                encodings.append("JWT")
        except Exception:
            pass

        return encodings if encodings else None

    def detect_hash(self, text):
        algo = None
        for pattern, algorithm in self.HASH_PATTERNS.items():
            if re.match(pattern, text):
                algo = algorithm
                break
        return algo if algo else "Not Detected"

    def analyze(self, inpt):
        algo = self.detect_hash(inpt)
        encodings = self.detect_encoding(inpt)
        self.display_result(inpt, algo, encodings)

    @staticmethod
    def display_result(inpt, algo, encodings):
        print(f"\n[+] Cipher Text: {inpt}")
        print(f"[+] Hash Detected: {algo}")
        if encodings:
            print(f"[+] Encodings Detected: {', '.join(encodings)}")
        else:
            print("[+] Encodings Detected: Not Detected")
        print("[!] Successfully Analyzed.....")

class CLI:
    def __init__(self):
        self.hash_identifier = HashIdentifier()

    @staticmethod
    def clear_screen():
        os.system("cls" if sys.platform == "win32" else "clear")

    @staticmethod
    def load(s):
        for c in s + '\n':
            sys.stdout.write(c)
            sys.stdout.flush()
            time.sleep(random.random() * 0.1)

    def main(self):
        print(pyfiglet.figlet_format("Hash Identifier"), end="")
        print("Mengidentifikasi jenis hash atau encoding pada teks yang diberikan\n")
        print("[@] Author: Fierza-Dev\n[-] Version : 1.2.0 (Improved)\n\n")

        parser = argparse.ArgumentParser()
        parser.add_argument('-cp', '--cipher', help='CipherText', dest='cp', required=True)
        args = parser.parse_args()
        inpt = args.cp.strip()

        if not inpt:
            print("[!] Error: Input cannot be empty.")
            sys.exit(1)

        print("Analyzing", end="")
        self.load("..........")
        time.sleep(2)

        self.hash_identifier.analyze(inpt)

if __name__ == '__main__':
    install_packages()
    if sys.version_info < (3, 0):
        sys.stdout.write("[!] Sorry, Hash-Identifier requires Python 3.x\n")
        sys.exit(1)
    else:
        cli = CLI()
        cli.clear_screen()
        cli.main()
