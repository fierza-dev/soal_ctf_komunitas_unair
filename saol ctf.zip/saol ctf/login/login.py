import base64


print(""" 
 __  __          _ _         ____             _       _ 
|  \/  | ___  __| (_) __ _  / ___|  ___   ___(_) __ _| |
| |\/| |/ _ \/ _` | |/ _` | \___ \ / _ \ / __| |/ _` | |
| |  | |  __/ (_| | | (_| |  ___) | (_) | (__| | (_| | |
|_|  |_|\___|\__,_|_|\__,_| |____/ \___/ \___|_|\__,_|_|

""")

_ = "VFZSSmVrNUVWVEpPZW1jMVRVRQ"

__ = input("Masukkan username : ")
___ = input("Masukkan Password : ")

_i_ = base64.b64encode(base64.b64encode(___.encode('utf-8'))).decode('utf-8')

__i_ = base64.b64decode(base64.b64decode(_i_).decode('utf-8')).decode("utf-8")

x = (
    base64.b64decode("Umt4QlIzdERVMGxTVkY4eU1ESTBWVTVCU1ZKZlRFOUhTVTU5").decode('utf-8')
    if __ == "aku.haiker123" and _i_ == __i_
    else "Username atau Password Salah!"
)

print("Login Berhasil!" if __ == "aku.haiker123" and _i_ == __i_ else x)

